import json,pickle,numpy as np
from shapely.geometry import Polygon,box,LineString
from shapely.ops import unary_union
B='/home/claude/BD_STUROVA/vystupy/BD_STUROVA_zaklady_v02/'
d=pickle.load(open('nk.pkl','rb'));el=json.load(open(B+'model_data.json'))['elements'];ps=json.load(open(B+'polygons.json'))
MN=unary_union([Polygon(e['xy'],e['holes']) for e in el if e['kind'] not in('patka','pas_sustava')])
FU=unary_union([Polygon(e['xy'],e['holes']) for e in el if e['kind'] in('patka','pas_sustava')]+[Polygon(ps[i]['xy']) for i in (31,41)])
H=[];V=[]
for s in d['allk']:
  (x1,y1),(x2,y2)=s.coords
  if abs(y1-y2)<1e-3 and abs(x1-x2)>0.3:H.append((round((y1+y2)/2,4),min(x1,x2),max(x1,x2)))
  elif abs(x1-x2)<1e-3 and abs(y1-y2)>0.3:V.append((round((x1+x2)/2,4),min(y1,y2),max(y1,y2)))
def pairs(S,horiz):
  out=[]
  S=sorted(S)
  for i,(c1,a1,b1) in enumerate(S):
    for c2,a2,b2 in S[i+1:]:
      dd=c2-c1
      if dd<0.18:continue
      if dd>0.65:break
      a,b=max(a1,a2),min(b1,b2)
      if b-a<0.3:continue
      # no line between
      if any(c1+1e-3<c3<c2-1e-3 and min(b3,b)-max(a3,a)>0.1 for c3,a3,b3 in S):continue
      out.append(box(a,c1,b,c2) if horiz else box(c1,a,c2,b))
  return out
R=unary_union(pairs(H,True)+pairs(V,False))
cand=R.difference(MN.buffer(0.005))
parts=[p for p in (cand.geoms if hasattr(cand,'geoms') else [cand]) if p.area>0.05 and 2*p.area/p.length>0.12]
print(len(parts),round(sum(p.area for p in parts),2))
for p in sorted(parts,key=lambda p:-p.area):print(round(p.area,3),round(2*p.area/p.length,3),[round(v,2) for v in p.bounds])
pickle.dump(parts,open('bands.pkl','wb'))
