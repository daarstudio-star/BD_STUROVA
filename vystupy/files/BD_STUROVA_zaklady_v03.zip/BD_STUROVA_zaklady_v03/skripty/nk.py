import json,numpy as np,pickle,collections
from shapely.geometry import LineString,Polygon,Point
from shapely.ops import unary_union,polygonize
from scipy.spatial import cKDTree
B='/home/claude/BD_STUROVA/vystupy/BD_STUROVA_zaklady_v02/'
al=json.load(open(B+'aligned.json'));O=np.array([4980696.,-1499500.])
def L(p):return ((p['x']-O[0])/1e3,(p['y']-O[1])/1e3)
red=[];blue=[]
for e in al:
  if e['layer']!='TENKÁ' or e.get('lineType'):continue
  if e['type']=='LINE':pts=[L(e['startPoint']),L(e['endPoint'])]
  elif e['type']=='LWPOLYLINE':
    if e.get('lineweight')!=7:continue
    pts=[L(p) for p in e['vertices']]
    if e.get('flag',0)&1:pts.append(pts[0])
  else:continue
  sg=[LineString([a,b]) for a,b in zip(pts,pts[1:]) if np.hypot(a[0]-b[0],a[1]-b[1])>1e-4]
  (red if e.get('lineweight')==7 else blue).extend(sg)
print(len(red),len(blue))
def snapset(segs,tol=0.012):
  pts=np.array([c for s in segs for c in s.coords]);t=cKDTree(pts);grp=-np.ones(len(pts),int);g=0
  for i in range(len(pts)):
    if grp[i]>=0:continue
    idx=[j for j in t.query_ball_point(pts[i],tol) if grp[j]<0];grp[idx]=g;g+=1
  cen=np.zeros((g,2));cnt=np.zeros(g)
  for i,k in enumerate(grp):cen[k]+=pts[i];cnt[k]+=1
  cen/=cnt[:,None];out=[]
  for k in range(0,len(pts),2):
    a=tuple(cen[grp[k]]);b=tuple(cen[grp[k+1]])
    if a!=b:out.append(LineString([a,b]))
  return out
allk=snapset(red+blue)
U=unary_union(allk);faces=list(polygonize(U));print('faces',len(faces))
segsU=list(U.geoms);deg=collections.Counter()
for s in segsU:
  cs=list(s.coords);deg[tuple(np.round(cs[0],3))]+=1;deg[tuple(np.round(cs[-1],3))]+=1
dang=[p for p,d in deg.items() if d==1];print('dangling',len(dang))
pickle.dump(dict(red=red,blue=blue,allk=allk,faces=faces,dang=dang),open('nk.pkl','wb'))
