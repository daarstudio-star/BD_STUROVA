import pickle,json,numpy as np,collections
from shapely.geometry import LineString,Polygon,Point
from shapely.ops import unary_union,polygonize
from scipy.spatial import cKDTree
r=pickle.load(open('rec.pkl','rb'))
def snapset(segs,tol=0.012):
  pts=np.array([c for s in segs for c in s.coords])
  t=cKDTree(pts);grp=-np.ones(len(pts),int);g=0
  for i in range(len(pts)):
    if grp[i]>=0:continue
    idx=t.query_ball_point(pts[i],tol);idx=[j for j in idx if grp[j]<0]
    grp[idx]=g;g+=1
  cen=np.zeros((g,2));cnt=np.zeros(g)
  for i,k in enumerate(grp):cen[k]+=pts[i];cnt[k]+=1
  cen/=cnt[:,None]
  out=[];k=0
  for s in segs:
    a=tuple(cen[grp[k]]);b=tuple(cen[grp[k+1]]);k+=2
    if np.hypot(a[0]-b[0],a[1]-b[1])>1e-4:out.append(LineString([a,b]))
  return out
blk=snapset(r['blk'])
# extend: also snap endpoints onto nearby segments (T-junctions)
U=unary_union(blk)
fb=list(polygonize(U))
print('faces',len(fb))
def parity(pt,segs):
  x,y=pt;c=0
  for s in segs:
    (x1,y1),(x2,y2)=s.coords
    if (y1>y)!=(y2>y):
      xi=x1+(y-y1)*(x2-x1)/(y2-y1)
      if xi>x:c+=1
  return c%2
# dangling endpoints
deg=collections.Counter()
for s in blk:
  for c in s.coords:deg[(round(c[0],4),round(c[1],4))]+=1
segsU=list(U.geoms) if hasattr(U,'geoms') else [U]
# endpoints after noding
deg2=collections.Counter()
for s in segsU:
  cs=list(s.coords);deg2[tuple(np.round(cs[0],4))]+=1;deg2[tuple(np.round(cs[-1],4))]+=1
dang=[p for p,d in deg2.items() if d==1]
print('dangling endpoints',len(dang));print(dang[:40])
pickle.dump(dict(blk=blk,faces=fb,dang=dang),open('rec2.pkl','wb'))
