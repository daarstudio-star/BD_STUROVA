import json,collections
from shapely.geometry import Polygon,Point
rows=json.load(open('dims.json'))
M=json.load(open('/mnt/user-data/outputs/BD_STUROVA_zaklady_v03/model_data.json'))['prvky']
lv=json.load(open('levels.json'))
def chain(a,b,edges):
  # BFS over positions
  adj=collections.defaultdict(set)
  for u,v in edges:adj[u].add(v);adj[v].add(u)
  start=[n for n in adj if abs(n-a)<0.006];goal=lambda n:abs(n-b)<0.006
  seen=set(start);st=list(start)
  while st:
    u=st.pop()
    if goal(u):return True
    for v in adj[u]:
      if v not in seen and min(a,b)-0.01<=v<=max(a,b)+0.01:seen.add(v);st.append(v)
  return False
res=[]
for m in M:
  if m['typ'] not in('zakladova_patka','zakladovy_pas'):continue
  g=Polygon(m['xy'],m['holes']);x0,y0,x1,y1=g.bounds
  ex=[];ey=[]
  for r in rows:
    (ax,ay),(bx,by)=r['p1'],r['p2']
    if abs(ay-by)<0.01 or (abs(ax-bx)>0.01 and abs(ay-by)<abs(ax-bx)):  # horizontal-ish measure in x
      if y0-3<(ay+by)/2<y1+3 and x0-0.01<=min(ax,bx) and max(ax,bx)<=x1+0.01:ex.append((round(ax,3),round(bx,3)))
    if abs(ax-bx)<0.01 or (abs(ay-by)>abs(ax-bx)):
      if x0-3<(ax+bx)/2<x1+3 and y0-0.01<=min(ay,by) and max(ay,by)<=y1+0.01:ey.append((round(ay,3),round(by,3)))
  cx=chain(round(x0,3),round(x1,3),ex);cy=chain(round(y0,3),round(y1,3),ey)
  lab=[(t,b) for x,y,t,b in lv['pairs'] if g.distance(Point(x,y))<0.05 and round(t-b,3)==0.8]
  okl=any(abs(t-m['zmax'])<1e-6 and abs(b-m['zmin'])<1e-6 for t,b in lab)
  res.append(dict(id=m['id'],v02=m['id_v02'],typ=m['typ'],blok=m['blok'],rozmer=f"{m['sirka_mm']} × {m['dlzka_mm']}",X=cx,Y=cy,kota=okl,zdroj=m['zdroj'],zmin=m['zmin'],zmax=m['zmax'],obj=m['objem_m3']))
c=collections.Counter((r['typ'],r['X'],r['Y'],r['kota']) for r in res);print(c)
for r in res:
  if r['typ']=='zakladova_patka' and not(r['X'] and r['Y'] and r['kota']):print(r)
json.dump(res,open('patky.json','w'),ensure_ascii=False)
