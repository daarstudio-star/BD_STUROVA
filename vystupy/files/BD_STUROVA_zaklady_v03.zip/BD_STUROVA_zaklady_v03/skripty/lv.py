import json,numpy as np,collections
from shapely.geometry import Polygon,Point
B='/home/claude/BD_STUROVA/vystupy/BD_STUROVA_zaklady_v02/'
el=json.load(open(B+'model_data.json'))['elements'];al=json.load(open(B+'aligned.json'));O=np.array([4980696.,-1499500.])
P={e['id']:Polygon(e['xy'],e['holes']) for e in el};EL={e['id']:e for e in el}
T=[];
for e in al:
  if e['type']=='TEXT' and e['text'].startswith('-'):
    x,y=(e['startPoint']['x']-O[0])/1e3,(e['startPoint']['y']-O[1])/1e3;T.append([x,y,float(e['text'].replace(',','.')),e['handle']])
used=set();pairs=[]
T.sort(key=lambda t:-t[1])
for i,a in enumerate(T):
  if i in used:continue
  best=None
  for j,b in enumerate(T):
    if j==i or j in used:continue
    if abs(a[0]-b[0])<0.15 and 0.1<a[1]-b[1]<0.4:
      if best is None or a[1]-b[1]<T[best][1]-a[1]+99:best=j
  if best is not None:
    b=T[best];used|={i,best};pairs.append((a[0],(a[1]+b[1])/2,a[2],b[2]))
single=[T[i] for i in range(len(T)) if i not in used]
print('texts',len(T),'pairs',len(pairs),'single',len(single))
print(collections.Counter((p[2],p[3]) for p in pairs))
F=[e for e in el if e['kind'] in('patka','pas_sustava')];N=[e for e in el if e['kind'] not in('patka','pas_sustava')]
out=[];stat=collections.Counter()
for x,y,top,bot in pairs:
  pt=Point(x,y)
  if top in(-4.2,-4.6,-5.0) and round(bot-top,3)==-0.8:
    cand=[e for e in F if P[e['id']].distance(pt)<0.05]
    kind='zaklad'
  else:
    cand=sorted([e for e in N if P[e['id']].distance(pt)<1.2],key=lambda e:P[e['id']].distance(pt))
    kind='krcok'
  if not cand: stat[kind+'_bez_prvku']+=1;out.append((kind,x,y,top,bot,None,'ziadny prvok modelu v okoli'));continue
  ok=[e for e in cand if abs(e['zmax']-top)<1e-6 and abs(e['zmin']-bot)<1e-6]
  if ok: stat[kind+'_zhoda']+=1;out.append((kind,x,y,top,bot,ok[0]['id'],'OK'))
  else:
    e=cand[0];stat[kind+'_rozdiel']+=1;out.append((kind,x,y,top,bot,e['id'],f"model {e['zmax']}/{e['zmin']}"))
print(stat)
for o in out:
  if o[6]!='OK':print(o)
# each element: has at least one matching label?
hit=collections.Counter(o[5] for o in out if o[6]=='OK')
print('elements without confirming label:',[e['id'] for e in el if not hit[e['id']]])
json.dump(dict(pairs=pairs,out=out,single=single),open('levels.json','w'))
