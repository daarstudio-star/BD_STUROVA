import json,pickle,numpy as np,collections,csv
from shapely.geometry import Polygon,Point,MultiPolygon
from shapely.ops import unary_union
B='/home/claude/BD_STUROVA/vystupy/BD_STUROVA_zaklady_v02/'
el=json.load(open(B+'model_data.json'))['elements'];ps=json.load(open(B+'polygons.json'));ns=json.load(open(B+'necks.json'))
lv=json.load(open('levels.json'));faces=pickle.load(open('rec2.pkl','rb'))['faces'];bands=pickle.load(open('bands.pkl','rb'))
def P(xy,h=()):return Polygon(xy,list(h))
def parts(g):return [p for p in (g.geoms if hasattr(g,'geoms') else [g]) if p.geom_type=='Polygon' and p.area>1e-4]
# ---------- footings
F=[]
for e in el:
  if e['kind'] in('patka','pas_sustava'):
    F.append(dict(v02=e['id'],geom=P(e['xy'],e['holes']),zmin=e['zmin'],zmax=e['zmax'],src='A – pôdorys základov, kóta',note=''))
hole=[f for f in faces if abs(f.bounds[0]-9.425)<0.01 and abs(f.bounds[1]-11.632)<0.01][0]
f0=[f for f in F if f['v02']=='F00'][0];f0['geom']=f0['geom'].difference(hole);f0['note']='Doplnený otvor 3,07 m² v JZ jadre (v0.2 chýbal, obrys v DWG neuzavretý o 4 mm).'
F.append(dict(v02='P31',geom=P(ps[31]['xy']),zmin=-5.4,zmax=-4.6,src='A – rez F-F (kóty −5,400/−4,600, 800)',note='V0.2 bez objemu.'))
F.append(dict(v02='P41',geom=P(ps[41]['xy']),zmin=-5.4,zmax=-4.6,src='B – odvodené zo susedných F20, F40; v reze nie je',note='V0.2 bez objemu. Overiť.'))
for f in F:f['typ']='zakladova_patka' if (f['geom'].area<15 and f['v02']!='F21') else 'zakladovy_pas'
FU=unary_union([f['geom'] for f in F])
# ---------- necks / beams (declared bottom/top)
K=[]
for e in el:
  if e['kind'] in('patka','pas_sustava'):continue
  src='A – pôdorys, kóta' if e['status'] in('jednoznacna_kota_podorysu','explicitna_kota_podla_oblasti_vykresu') else 'B – pracovná geometria v0.2 (koncové stupne)'
  K.append(dict(v02=e['id'],geom=P(e['xy'],e['holes']),zb=e['zmin'],zt=e['zmax'],typ='zakladovy_tram' if e['kind']=='zakladovy_tram' else 'zakladovy_krcok',src=src,note=''))
add={11:(-4.2,-3.67,'A – pôdorys, kóty −3,670/−4,200 v JZ jadre'),12:(-5.0,-3.67,'B – odvodené z kóty −3,670/−5,000 pri JV jadre'),23:(-5.0,-3.67,'B – odvodené z kóty −3,670/−5,000 pri JV jadre'),27:(-5.0,-3.67,'B – odvodené z kóty −3,670/−5,000 pri JV jadre'),
 55:(-4.6,-3.45,'A – pôdorys, kóta −3,450/−4,600'),59:(-4.6,-3.67,'B – odvodené (P41 bez kót)'),60:(-4.6,-3.67,'A – pôdorys, kóta −3,670/−4,600'),64:(-4.2,-3.45,'A – pôdorys, kóta −3,450/−4,200'),75:(-4.6,-3.67,'A – rez F-F (kóta −3,670, 930)')}
KU=unary_union([k['geom'] for k in K])
for i,(zb,zt,src) in add.items():
  g=P(ns[i]['xy'],ns[i]['holes']).difference(KU)
  for p in parts(g):
    if p.area<0.02:continue
    K.append(dict(v02=f'N{i:02}',geom=p,zb=zb,zt=zt,typ='zakladovy_tram' if p.area>1 else 'zakladovy_krcok',src=src,note='V0.2 nedoriešené, doplnené.'))
KU=unary_union([k['geom'] for k in K])
# perimeter / core bands
neck_labels=[(x,y,t,b) for x,y,t,b in lv['pairs'] if t>-4.0]
nkf0=pickle.load(open('nk.pkl','rb'))['faces']
DIL0=unary_union([f for f in nkf0 if f.area>0.005 and 2*f.area/f.length<0.06])
BU=unary_union(bands+pickle.load(open('corners.pkl','rb'))).difference(KU).difference(DIL0)
BU=BU.buffer(-0.0005,join_style=2).buffer(0.0005,join_style=2)
for p0 in [BU]:
  for p in parts(p0):
    if p.area<0.05 or 2*p.area/p.length<0.12:continue
    # declared bottom: footing with largest overlap, else nearest footing
    ov=sorted(((p.intersection(f['geom']).area,f) for f in F),key=lambda t:-t[0])
    fb=ov[0][1] if ov[0][0]>1e-3 else min(F,key=lambda f:f['geom'].distance(p))
    zb=fb['zmax']
    cand=sorted(((p.distance(Point(x,y)),t,b) for x,y,t,b in neck_labels if abs(b-zb)<1e-6),key=lambda c:c[0])
    if cand and cand[0][0]<1.5:zt=cand[0][1];src=f'A – pôdorys, kóta {zt:.3f}/{zb:.3f} pri prvku'.replace('.',',')
    elif cand:zt=cand[0][1];src=f'B – kóta {zt:.3f}/{zb:.3f} na tom istom obvode, {cand[0][0]:.1f} m od prvku'.replace('.',',')
    else:zt=-3.67;src='B – bez kóty, prevzaté −3,670 (typická úroveň)'
    K.append(dict(v02='',geom=p,zb=zb,zt=zt,typ='zakladovy_krcok' if 2*p.area/p.length<0.45 else 'zakladovy_tram',src=src,note='Obvodový krčok / krčok jadra – v0.2 chýbal, geometria z dvojice čiar DWG.'))
    KU=KU.union(p)
nkf=pickle.load(open('nk.pkl','rb'))['faces']
DIL=unary_union([f for f in nkf if f.area>0.005 and 2*f.area/f.length<0.06])
print('dilatacne skary',len(parts(DIL)),round(DIL.area,3))
newK=[]
for k in K:
  g=k['geom'].difference(DIL)
  ps_=[p for p in parts(g) if p.area>0.01]
  if len(ps_)>1: print('rozdelene dilataciou',k['v02'] or 'NEW',len(ps_))
  for p in ps_:
    kk=dict(k);kk['geom']=p;newK.append(kk)
K=newK
# ---------- split necks by footing tops -> pieces
for k in K:
  pcs=[];rest=k['geom']
  for f in F:
    g=k['geom'].intersection(f['geom'])
    for p in parts(g):
      if p.area>1e-4:pcs.append((p,f['zmax']));rest=rest.difference(p)
  for p in parts(rest):
    if p.area>1e-4:pcs.append((p,k['zb']))
  k['pieces']=pcs
  chg=[z for _,z in pcs if abs(z-k['zb'])>1e-6]
  if chg:k['note']=(k['note']+' ' if k['note'] else '')+'Spodok rozdelený podľa vrchu základu pod prvkom ('+', '.join(sorted({f'{z:.3f}'.replace('.',',') for z in [k['zb']]+chg}))+').'
# ---------- podkladny beton
PB=[dict(v02=f['v02'],geom=f['geom'],zmin=f['zmin']-0.1,zmax=f['zmin'],typ='podkladny_beton',src='A – statický posudok: 100 mm, C16/20',note='') for f in F]
pickle.dump(dict(F=F,K=K,PB=PB),open('v03.pkl','wb'))
print('footings',len(F),'necks',len(K),'pb',len(PB))
print(collections.Counter(k['src'][:1] for k in K))
