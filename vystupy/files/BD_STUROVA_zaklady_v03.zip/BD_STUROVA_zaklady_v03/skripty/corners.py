import pickle
from shapely.geometry import box
from shapely.ops import unary_union
exec(open('band.py').read().split('R=unary_union')[0])
ph=pairs(H,True);pv=pairs(V,False)
C=[]
for h in ph:
  hx0,hy0,hx1,hy1=h.bounds
  for v in pv:
    vx0,vy0,vx1,vy1=v.bounds
    c=box(vx0,hy0,vx1,hy1)
    if c.area<1e-4 or c.area>0.5:continue
    if c.intersection(h).area>1e-5 or c.intersection(v).area>1e-5:continue
    if c.distance(h)<0.005 and c.distance(v)<0.005: C.append(c)
CU=unary_union(C)
print(len(C))
for c in (CU.geoms if hasattr(CU,'geoms') else [CU]):print([round(x,3) for x in c.bounds])
pickle.dump(C,open('corners.pkl','wb'))
