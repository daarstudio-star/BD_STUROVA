import json,numpy as np,collections,pickle
from shapely.geometry import LineString,Polygon,Point
from shapely.ops import unary_union,polygonize
B='/home/claude/BD_STUROVA/vystupy/BD_STUROVA_zaklady_v02/'
al=json.load(open(B+'aligned.json'));O=np.array([4980696.,-1499500.])
def L(p):return (round((p['x']-O[0])/1e3,4),round((p['y']-O[1])/1e3,4))
blk=[];nk=[]
for e in al:
  if e['type'] not in('LINE','LWPOLYLINE'):continue
  lt=e.get('lineType','')
  if e['type']=='LINE':pts=[L(e['startPoint']),L(e['endPoint'])]
  else:
    pts=[L(p) for p in e['vertices']]
    if e.get('flag',0)&1:pts.append(pts[0])
  sg=[LineString([a,b]) for a,b in zip(pts,pts[1:]) if a!=b]
  if e['layer']=='MÚRY' and not lt and e.get('lineweight')==8:blk+=sg
  elif e['layer']=='TENKÁ' and not lt and (e.get('lineweight')==7 or (e['type']=='LINE')):nk+=sg
print(len(blk),len(nk))
def parity(pt,segs,dirn):
  x,y=pt;c=0
  for s in segs:
    (x1,y1),(x2,y2)=s.coords
    if (y1>y)!=(y2>y):
      xi=x1+(y-y1)*(x2-x1)/(y2-y1)
      if (xi>x) if dirn>0 else (xi<x):c+=1
  return c%2
fb=list(polygonize(unary_union(blk)));print('black faces',len(fb))
foot=[];amb=0
for f in fb:
  rp=f.representative_point();a=parity((rp.x,rp.y+1e-4),blk,1);b=parity((rp.x,rp.y+1e-4),blk,-1)
  if a!=b:amb+=1
  if a and b:foot.append(f)
FU=unary_union(foot);print('ambiguous',amb,'footing area',round(FU.area,2))
pickle.dump(dict(blk=blk,nk=nk,foot=FU),open('rec.pkl','wb'))
el=json.load(open(B+'model_data.json'))['elements']
MF=unary_union([Polygon(e['xy'],e['holes']) for e in el if e['kind'] in('patka','pas_sustava')])
ps=json.load(open(B+'polygons.json'))
print('model footing area',round(MF.area,2))
extra=MF.difference(FU);miss=FU.difference(MF)
def parts(g):return [p for p in (g.geoms if hasattr(g,'geoms') else [g]) if p.area>0.01]
print('model navyse');[print(round(p.area,3),[round(v,2) for v in p.bounds]) for p in parts(extra)]
print('vo vykrese, v modeli chyba');[print(round(p.area,3),[round(v,2) for v in p.bounds]) for p in parts(miss)]
