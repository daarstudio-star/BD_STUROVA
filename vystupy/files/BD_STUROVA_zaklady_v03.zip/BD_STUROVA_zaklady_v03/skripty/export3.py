import pickle,json,csv,itertools,collections,numpy as np,trimesh,os,shutil
from shapely.geometry import Polygon,box
from shapely.ops import unary_union
d=pickle.load(open('v03.pkl','rb'));F,K,PBs=d['F'],d['K'],d['PB']
Z0=263.65
MAT={'zakladova_patka':'C25/30 – XC3, XD1, XA1; B500B','zakladovy_pas':'C25/30 – XC3, XD1, XA1; B500B','zakladovy_krcok':'C25/30 – XC3, XD1, XA1; B500B','zakladovy_tram':'C25/30 – XC3, XD1, XA1; B500B','podkladny_beton':'C16/20'}
NAME={'zakladova_patka':'Základová pätka','zakladovy_pas':'Základový pás','zakladovy_krcok':'Základový krčok','zakladovy_tram':'Základový trám','podkladny_beton':'Podkladný betón'}
PFX={'zakladova_patka':'ZP','zakladovy_pas':'ZS','zakladovy_krcok':'ZK','zakladovy_tram':'ZT'}
Q={'B':box(-5,-5,26.73,30.5),'A':box(26.73,-5,65,30.5),'CD-SZ':box(-5,30.5,26.73,65),'CD-SV':box(26.73,30.5,65,65)}
def blok(g):
  r=[k for k,b in Q.items() if g.intersection(b).area/g.area>0.05];return ' + '.join(sorted(r))
E=[]
for f in F:E.append(dict(typ=f['typ'],geom=f['geom'],pieces=[(f['geom'],f['zmin'],f['zmax'])],v02=f['v02'],src=f['src'],note=f['note']))
for k in K:E.append(dict(typ=k['typ'],geom=k['geom'],pieces=[(p,zb,k['zt']) for p,zb in k['pieces']],v02=k['v02'],src=k['src'],note=k['note']))
cnt=collections.Counter()
for t in ['zakladovy_pas','zakladova_patka','zakladovy_tram','zakladovy_krcok']:
  L=[e for e in E if e['typ']==t]
  L.sort(key=lambda e:(-round(e['geom'].centroid.y),round(e['geom'].centroid.x,1)))
  for i,e in enumerate(L,1):e['id']=f"{PFX[t]}-{i:02d}"
fid={f['v02']:e['id'] for f,e in zip(F,E[:len(F)])}
for f,p in zip(F,PBs):
  E.append(dict(typ='podkladny_beton',geom=p['geom'],pieces=[(p['geom'],p['zmin'],p['zmax'])],v02='',src=p['src'],note='',id='PB-'+fid[f['v02']],pod=fid[f['v02']]))
# overlap check (all pieces)
P=[(e['id'],g,a,b) for e in E for g,a,b in e['pieces']]
ov=[]
for (i1,g1,a1,b1),(i2,g2,a2,b2) in itertools.combinations(P,2):
  if i1==i2:continue
  z=min(b1,b2)-max(a1,a2)
  if z<=1e-6 or not g1.intersects(g2):continue
  A=g1.intersection(g2).area
  if A*z>1e-4:ov.append((i1,i2,round(A*z,4)))
print('prieniky',ov[:20],len(ov))
# gaps: neck piece bottom vs footing top check
out='/mnt/user-data/outputs/BD_STUROVA_zaklady_v03';os.makedirs(out,exist_ok=True)
scene=trimesh.Scene();meta=[]
COL={'zakladova_patka':'#5e82a2','zakladovy_pas':'#8da99a','zakladovy_krcok':'#d2b48c','zakladovy_tram':'#c99a5b','podkladny_beton':'#b9b9b9'}
for e in E:
  ms=[]
  for g,a,b in e['pieces']:
    for gg in (g.geoms if hasattr(g,'geoms') else [g]):
      m=trimesh.creation.extrude_polygon(gg.buffer(0),b-a,engine='earcut');m.apply_translation([0,0,a]);ms.append(m)
  m=trimesh.util.concatenate(ms);c=np.array(trimesh.visual.color.hex_to_rgba(COL[e['typ']]));m.visual.face_colors=c
  scene.add_geometry(m,node_name=e['id'],geom_name=e['id'])
  vol=sum(g.area*(b-a) for g,a,b in e['pieces'])
  zs=[a for _,a,_ in e['pieces']]+[b for _,_,b in e['pieces']]
  g=e['geom'];bx=g.bounds
  meta.append(dict(id=e['id'],nazov=NAME[e['typ']],typ=e['typ'],blok=blok(g),material=MAT[e['typ']],id_v02=e['v02'],pod_prvkom=e.get('pod',''),
    zmin=round(min(zs),3),zmax=round(max(zs),3),zmin_abs=round(Z0+min(zs),3),zmax_abs=round(Z0+max(zs),3),
    sirka_mm=round((bx[2]-bx[0])*1000),dlzka_mm=round((bx[3]-bx[1])*1000),plocha_m2=round(g.area,4),objem_m3=round(vol,4),
    casti=[dict(spodok=round(a,3),vrch=round(b,3),plocha_m2=round(gg.area,4)) for gg,a,b in e['pieces']],
    zdroj=e['src'],poznamka=e['note'],xy=[[round(x,4),round(y,4)] for x,y in g.exterior.coords],holes=[[[round(x,4),round(y,4)] for x,y in r.coords] for r in g.interiors],
    pieces=[dict(xy=[[round(x,4),round(y,4)] for x,y in gg.exterior.coords],holes=[[[round(x,4),round(y,4)] for x,y in r.coords] for r in gg.interiors],zmin=a,zmax=b) for gg0,a,b in e['pieces'] for gg in (gg0.geoms if hasattr(gg0,'geoms') else [gg0])]))
scene.export(out+'/zaklady_v03.obj')
g2=scene.copy();g2.apply_transform(trimesh.transformations.rotation_matrix(-np.pi/2,[1,0,0]));g2.export(out+'/zaklady_v03.glb')
meta.sort(key=lambda m:(['ZS','ZP','ZT','ZK','PB'].index(m['id'][:2]),m['id']))
json.dump(dict(projekt='BD Štúrova, Žiar nad Hronom – SO-100',vrstva='ZÁKLADY',verzia='0.3',jednotky='m',projektova_nula_m_n_m=Z0,suradnice='lokálne CAD (pôvod DWG [4980696, -1499500] mm, CD posun −115361,5 mm); nie S-JTSK',
  pozn_bloky='B = JZ, A = JV podľa statického posudku; C/D severné celky nerozlíšené (CD-SZ, CD-SV).',prvky=meta),open(out+'/model_data.json','w'),ensure_ascii=False,indent=1)
with open(out+'/prvky_a_vysky.csv','w',newline='',encoding='utf-8-sig') as fh:
  w=csv.writer(fh,delimiter=';');w.writerow(['ID','Názov','Blok','Materiál','Spodok [m]','Vrch [m]','Spodok [m n. m.]','Vrch [m n. m.]','Rozmer X [mm]','Rozmer Y [mm]','Plocha [m²]','Objem [m³]','Pod prvkom','ID v0.2','Zdroj údaja','Poznámka'])
  for m in meta:w.writerow([m['id'],m['nazov'],m['blok'],m['material'],str(m['zmin']).replace('.',','),str(m['zmax']).replace('.',','),str(m['zmin_abs']).replace('.',','),str(m['zmax_abs']).replace('.',','),m['sirka_mm'],m['dlzka_mm'],str(m['plocha_m2']).replace('.',','),str(m['objem_m3']).replace('.',','),m['pod_prvkom'],m['id_v02'],m['zdroj'],m['poznamka']])
s=collections.defaultdict(lambda:[0,0.0])
for m in meta:s[m['nazov']][0]+=1;s[m['nazov']][1]+=m['objem_m3']
print({k:(v[0],round(v[1],2)) for k,v in s.items()})
print('ZB spolu',round(sum(v[1] for k,v in s.items() if k!='Podkladný betón'),2))
json.dump({k:(v[0],round(v[1],3)) for k,v in s.items()},open('sum3.json','w'),ensure_ascii=False)
