BD ŠTUROVA – VRSTVA ZÁKLADOV v0.3
Jednotky m, lokálne CAD súradnice (pôvod DWG [4980696; -1499500] mm), ±0,000 = 263,650 m n. m. OBJ Z-hore, GLB Y-hore.

NÁZVOSLOVIE (podľa statického posudku)
ZS-xx  základový pás (aj súvislé sústavy pásov)      C25/30 – XC3, XD1, XA1; B500B
ZP-xx  základová pätka                                C25/30 – XC3, XD1, XA1; B500B
ZT-xx  základový trám                                 C25/30 – XC3, XD1, XA1; B500B
ZK-xx  základový krčok (pod stĺpom aj stenou)          C25/30 – XC3, XD1, XA1; B500B
PB-ZP-xx / PB-ZS-xx  podkladný betón 100 mm pod daným prvkom   C16/20
Číslovanie v rámci typu zo severu na juh, zo západu na východ. Blok a ID v0.2 sú samostatné atribúty.
Bloky: B = JZ, A = JV (statický posudok); severné celky C/D nerozlíšené -> CD-SZ, CD-SV.

ZDROJ ÚDAJA
A = kóta priamo v pôdoryse základov alebo v reze; B = odvodené, treba overiť.

SÚHRN
Základový pás: 6 ks, 703,16 m3
Základová pätka: 35 ks, 163,62 m3
Základový trám: 26 ks, 120,25 m3
Základový krčok: 59 ks, 60,27 m3
Podkladný betón: 41 ks, 108,35 m3

ZMENY OPROTI v0.2: pozri prehliadač BD_STUROVA_zaklady_v03.html a stĺpec Poznámka v CSV.
NEOBSAHUJE: výstuž, podlahové dosky, štrkové lôžka, zásypy, stĺpy a steny prízemia.
Prvky s viac časťami (13) majú spodok rozdelený podľa vrchu základu; v GLB sú to zložené telesá s vnútornými stenami (objem sedí).
