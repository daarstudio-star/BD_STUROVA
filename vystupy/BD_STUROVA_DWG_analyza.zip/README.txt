Source: Google Drive Siituacia.dwg, id 1FLVeZpM125Mkjqgd2s_VOXwkCVutwYFz.
Decoded with @mlightcad/libredwg-web 0.8.0.
13748 entities. Raw CAD coordinates preserved; NO georeferencing applied.
Dimensions 60350 and 59250 match millimetre-scale drawing geometry. INSUNITS=0 (unspecified).
Two copies of situation identified, separated by 246803.5 drawing units along Y.
LIMMIN/LIMMAX and viewport centers contain other coordinate ranges; these are not verified georeferencing control points.
Do not use raw coordinates as S-JTSK. Transformation requires verified point correspondences.
